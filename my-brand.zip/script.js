document.getElementById("cta").addEventListener("click", () => {
  alert("Keren! Kamu siap mulai brand-mu 🎉");
});
